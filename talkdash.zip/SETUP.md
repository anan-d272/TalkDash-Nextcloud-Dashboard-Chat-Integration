# Setup Instructions for Talk Dashboard App

1. Copy the app into Nextcloud custom apps directory:
   ```bash
   sudo cp -r talkdash /var/www/html/nextcloud/custom_apps/
   ```

2. Fix permissions:
   ```bash
   sudo chown -R www-data:www-data /var/www/html/nextcloud/custom_apps/talkdash
   ```

3. Enable the app:
   ```bash
   cd /var/www/html/nextcloud
   sudo -u www-data php occ app:enable talkdash
   ```

4. Verify in Nextcloud dashboard — you should see **Talk Dashboard** widget.
