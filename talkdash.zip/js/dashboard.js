document.addEventListener('DOMContentLoaded', function() {
    const el = document.getElementById('talkdash-widget');
    if (el) {
        el.innerHTML = '<p>Welcome to Talk Dashboard Widget!</p>';
    }
});
