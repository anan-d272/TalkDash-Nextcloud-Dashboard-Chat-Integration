<?php

namespace OCA\TalkDash\Dashboard;

use OCP\Dashboard\IWidget;
use OCP\IL10N;

class TalkWidget implements IWidget {
    private $l;

    public function __construct(IL10N $l) {
        $this->l = $l;
    }

    public function getId(): string {
        return 'talkdash';
    }

    public function getTitle(): string {
        return $this->l->t('Talk Dashboard');
    }

    public function getIconClass(): string {
        return 'icon-contacts-dark';
    }

    public function load(): string {
        return '<div id="talkdash-widget">Talk Dashboard is working!</div>';
    }
}
