<?php

namespace OCA\TalkDash\AppInfo;

use OCP\AppFramework\App;
use OCP\Dashboard\IDashboardManager;
use OCP\Dashboard\IWidget;

class Application extends App {
    public function __construct(array $urlParams = []) {
        parent::__construct('talkdash', $urlParams);
        $container = $this->getContainer();
        $container->registerService(IWidget::class, function($c) {
            return $c->query('OCA\\TalkDash\\Dashboard\\TalkWidget');
        });
    }
}
