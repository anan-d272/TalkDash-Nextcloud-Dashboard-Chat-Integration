# Talk Dashboard (Nextcloud App)

A simple custom Nextcloud app that provides a dashboard widget for Nextcloud Talk.

## Features
- Adds a dashboard widget called "Talk Dashboard"
- Displays a placeholder widget (can be extended to show Talk conversations)

## Requirements
- Nextcloud 25+
- PHP 8+
- MariaDB/MySQL
